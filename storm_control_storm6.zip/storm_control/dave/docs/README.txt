You can generate Doxygen documentation by running doxygen in the folder that is one folder up from this file (The one that contains "Doxyfile").

