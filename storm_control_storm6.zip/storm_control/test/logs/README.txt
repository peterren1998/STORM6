
This is a place holder so that git will preserve this directory.

When testing this is where the logs files will end up.
