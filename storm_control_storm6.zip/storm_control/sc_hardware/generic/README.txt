
This folder is for modules that use other modules for functionality, but
unlike the HAL modules have nothing to do with the GUI.
